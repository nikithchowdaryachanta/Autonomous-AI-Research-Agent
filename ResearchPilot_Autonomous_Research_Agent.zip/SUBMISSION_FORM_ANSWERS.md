# Submission Form — Suggested Answers

## GitHub Repo / Code Link
`<PASTE YOUR GITHUB REPOSITORY URL AFTER PUSHING>`

## Upload Code
Upload `ResearchPilot_Autonomous_Research_Agent.zip`.

## Architecture Diagram
Upload `architecture_diagram.png`.

## Sample Run Transcripts/Logs
Upload `sample_run_transcript.md` or the generated execution log from a configured live run.

## Write-up (design decisions, limitations)
See `WRITEUP.md`.

## Which domain/goal did you choose for your agent?
I chose **Autonomous Research**. The agent accepts a research question, autonomously plans the information-gathering strategy, selects appropriate external source types, retrieves information in parallel, filters duplicate/low-relevance results, and generates a structured evidence-grounded report containing key points, important findings, references and actionable insights.

## Any assumptions or mock data used?
The agent assumes access to public external sources and API credentials supplied through environment variables. No private data is required. The evaluation suite uses synthetic test traces designed to test different research intents such as technology research, technical explanation, decision support and comparison.

## Total time spent (hours)
`ENTER YOUR ACTUAL TIME BEFORE SUBMISSION`

## Synthetic/Test Traces Used (with labels)
See `sample_data/test_traces.jsonl`. Four labeled traces are included:
- multi-source technology synthesis
- technical concept research
- action-oriented business research
- comparative research

## Monitoring Report / Dashboard Output
The Streamlit Monitoring tab reports:
- sources gathered
- sources retained
- duplicates removed
- planned query count
- references generated
- latency
- source-type distribution
- full execution trace

## Write-up (approach, precision/recall, production-readiness)
See `WRITEUP.md` and `researchpilot/evaluator.py`.

## How did you generate/label your test traces?
I manually designed synthetic research tasks covering different intent types. Each trace was assigned an intent label, expected source categories and evidence-theme labels. These labels are used for repeatable evaluation of retrieval behavior without hardcoding a single web answer.
