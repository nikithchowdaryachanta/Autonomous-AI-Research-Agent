# ResearchPilot — Autonomous Research Agent

**Assessment Option 1: Autonomous Research Agent**

ResearchPilot is an LLM-driven research agent that accepts a user topic, plans a research strategy, selects source types, gathers information from external sources, extracts evidence, removes duplicates/low-value results, synthesizes findings, and produces an actionable report with traceable references.

The implementation is intentionally modular and original. It does not use hardcoded answers for research topics.

## What it demonstrates

- Autonomous research planning using an LLM
- Dynamic source selection based on the query
- Parallel source retrieval
- Relevance scoring and duplicate detection
- Evidence-grounded synthesis
- Source/reference tracking
- Actionable insight generation
- Persistent search memory in SQLite
- Markdown and PDF report export
- Execution traces and monitoring metrics
- Streamlit UI for a live demonstration
- Test traces with labels for evaluation

## Architecture

```text
User Query
    |
    v
Query Planner (LLM)
    |
    +---- source strategy ----+
    |                         |
    v                         v
Tavily/Web Search       Wikipedia Search
    |                         |
    +-----------+-------------+
                |
                v
       Normalization/Extraction
                |
                v
      Relevance + Deduplication
                |
                v
       Evidence Pack Builder
                |
                v
        LLM Research Synthesizer
                |
        +-------+--------+
        |                |
        v                v
 Markdown/PDF       SQLite Memory
        |
        v
 Monitoring / Trace Dashboard
```

## Installation

Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env
```

Set at least one LLM provider:

```env
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-5-mini
```

For richer web search, set:

```env
TAVILY_API_KEY=your_key
```

If Tavily is not configured, ResearchPilot can still use the Wikipedia external source adapter for demonstration/testing.

Run:

```bash
streamlit run app.py
```

Or CLI:

```bash
python -m researchpilot.cli "What are the main applications of retrieval augmented generation?"
```

## API keys and security

Never commit `.env` or API keys. `.gitignore` already excludes secrets, runtime databases and generated reports.

## Agent behavior

The LLM receives a planning prompt and returns a structured research plan. The plan determines the preferred source categories and query variants. Retrieval is then performed concurrently. The LLM does not directly invent sources: source metadata is supplied by the retrieval layer and included in the evidence pack.

The final synthesis prompt explicitly requires:
1. claims to be grounded in supplied evidence;
2. source IDs for material claims;
3. uncertainty when evidence is insufficient;
4. no fabricated references.

## Evaluation

`sample_data/test_traces.jsonl` contains labeled test tasks. Each trace includes:
- query
- intent
- expected source types
- expected evidence themes
- expected behaviors

`researchpilot/evaluator.py` computes lightweight retrieval precision/recall when expected evidence labels are available. These are test-set metrics, not claims about production web-search quality.

## Production-readiness notes

Current strengths:
- provider abstraction
- concurrent retrieval
- persistent memory
- structured outputs
- observability
- source traceability
- configurable model and search provider

Remaining work for production:
- authenticated multi-user storage
- rate limiting
- source reliability policies
- stronger citation verification
- PII/content safety filtering
- background job queue
- distributed tracing
- automated regression evaluation on a larger labeled benchmark

## Submission mapping

| Assessment requirement | Implementation |
|---|---|
| Accept user query/topic | Streamlit UI + CLI |
| Search external sources | Tavily + Wikipedia adapters |
| Extract relevant information | Normalization + evidence extraction |
| Remove duplicate/irrelevant content | Similarity/overlap filtering |
| Key points | LLM synthesis |
| Important findings | LLM synthesis |
| References/sources | Source registry + citations |
| Actionable insights | LLM synthesis |
| Autonomous source selection | LLM planner |
| Parallel gathering | ThreadPoolExecutor |
| Export Markdown/PDF | Report exporter |
| Previous searches in memory | SQLite memory store |

## License

For assessment/demo use.
