import json
from pathlib import Path
import streamlit as st
from researchpilot.agent import ResearchAgent
from researchpilot.config import Settings
from researchpilot.memory import MemoryStore
from researchpilot.reporting import markdown_report, pdf_report

st.set_page_config(page_title="ResearchPilot", page_icon="🔎", layout="wide")

st.title("🔎 ResearchPilot")
st.caption("Autonomous Research Agent — Assessment Option 1")

with st.sidebar:
    st.header("Configuration")
    st.write("The agent plans research dynamically and records an execution trace.")
    max_sources = st.slider("Maximum sources", 3, 12, 6)
    use_memory = st.checkbox("Use previous-search memory", True)
    st.divider()
    st.markdown("**Providers**")
    settings = Settings()
    st.write(f"LLM: `{settings.openai_model}`")
    st.write("Tavily: " + ("configured" if settings.tavily_api_key else "not configured"))
    st.info("For a richer demo, add TAVILY_API_KEY and OPENAI_API_KEY to `.env`.")

query = st.text_area(
    "Research topic / question",
    placeholder="Example: What are the main applications and limitations of retrieval augmented generation?",
    height=100,
)

if st.button("Run Autonomous Research", type="primary", disabled=not query.strip()):
    with st.spinner("Planning, researching, deduplicating and synthesizing..."):
        agent = ResearchAgent(settings)
        result = agent.run(query.strip(), max_sources=max_sources, use_memory=use_memory)
    st.session_state["result"] = result

result = st.session_state.get("result")
if result:
    m = result["metrics"]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Sources gathered", m["sources_gathered"])
    c2.metric("Sources retained", m["sources_retained"])
    c3.metric("Duplicates removed", m["duplicates_removed"])
    c4.metric("Latency", f'{m["latency_seconds"]:.1f}s')

    tabs = st.tabs(["Research Report", "Sources", "Agent Trace", "Monitoring"])
    with tabs[0]:
        st.markdown(result["report"]["markdown"])
        st.download_button(
            "Download Markdown",
            result["report"]["markdown"].encode(),
            file_name="research_report.md",
            mime="text/markdown",
        )
        st.download_button(
            "Download PDF",
            pdf_report(result["report"], result["sources"]),
            file_name="research_report.pdf",
            mime="application/pdf",
        )

    with tabs[1]:
        for s in result["sources"]:
            with st.expander(f'[{s["id"]}] {s["title"]}'):
                st.write(s.get("snippet", ""))
                st.write(f'Source: {s["url"]}')
                st.write(f'Relevance: {s.get("relevance_score", 0):.2f}')

    with tabs[2]:
        for event in result["trace"]:
            st.json(event)

    with tabs[3]:
        st.json(result["metrics"])
        st.subheader("Retrieved source types")
        counts = {}
        for s in result["sources"]:
            counts[s["source_type"]] = counts.get(s["source_type"], 0) + 1
        st.bar_chart(counts)

st.divider()
st.caption("ResearchPilot uses external evidence supplied by its retrieval layer and labels uncertainty rather than silently filling evidence gaps.")
