# Sample Run Transcript

> Demonstration trace format. A live run should be generated with configured API keys; this file documents the expected autonomous behavior and schema.

## Query

`What are the main applications and limitations of retrieval augmented generation?`

## Agent trace

```json
{"step":"received_query","query":"What are the main applications and limitations of retrieval augmented generation?"}
{"step":"planned_research","intent":"technology research","queries":["retrieval augmented generation applications","RAG limitations hallucination context retrieval"],"source_types":["technical documentation","encyclopedic sources","research sources"]}
{"step":"parallel_retrieval","raw_sources":8}
{"step":"filtering","retained":6,"duplicates_removed":2}
{"step":"synthesis_complete","references":6}
```

## Expected output characteristics

- Explain what RAG is using retrieved evidence.
- Identify application categories.
- Discuss limitations such as retrieval quality, context limits, stale/incorrect sources and citation/evidence issues when supported by the retrieved sources.
- Attach source IDs to material findings.
- State uncertainty where evidence is insufficient.
- Provide practical actions for someone evaluating a RAG system.

The exact factual output is intentionally generated at runtime from external evidence rather than hardcoded.
