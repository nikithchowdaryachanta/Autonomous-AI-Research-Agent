# Submission Runbook

1. Create a GitHub repository named `researchpilot-autonomous-agent`.
2. Upload all files in this package.
3. Locally create `.env` from `.env.example`.
4. Add `OPENAI_API_KEY`.
5. Add `TAVILY_API_KEY` for broader web search.
6. Run `pip install -r requirements.txt`.
7. Run `pytest -q`.
8. Run `streamlit run app.py`.
9. Execute at least one live query.
10. Save the resulting trace/report as the sample run evidence.
11. Put the GitHub URL into the assessment form.
12. Enter the actual development time in the form; do not estimate or copy a value from this package.
