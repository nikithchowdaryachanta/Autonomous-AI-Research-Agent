# Assessment Write-up — ResearchPilot

## Domain / goal

I selected **Autonomous Research Agent**. The goal is to automate a research workflow in which a user provides a topic, the agent determines an appropriate research strategy, gathers evidence from external sources, filters the evidence, and produces a structured report.

This directly maps to the assessment requirements for external information gathering, extraction, duplicate/irrelevance reduction, structured summaries, references and actionable insights.

## Design decisions

### 1. Planner + synthesizer separation

The agent uses two LLM stages:
- Planner: decides intent, query variants and source categories.
- Synthesizer: consumes only the retrieved evidence pack and produces the report.

This separation makes the system easier to inspect and evaluate.

### 2. Provider abstraction

Search is separated from the agent. Tavily provides general web retrieval and Wikipedia provides an encyclopedic source path. More providers can be added without changing the planner or synthesizer.

### 3. Parallel retrieval

Independent query/provider combinations execute concurrently. This reduces latency and demonstrates autonomous multi-source gathering.

### 4. Evidence filtering

The system canonicalizes URLs, calculates token overlap with the original question, and removes near-duplicate snippets using Jaccard similarity.

This is a lightweight first-stage filter rather than a claim that heuristic similarity is sufficient for production.

### 5. Traceability

Each source receives a stable source ID. The synthesis prompt requires material claims to include those IDs.

### 6. Memory

SQLite stores prior searches and their result JSON. This satisfies the assessment bonus while keeping the demo simple and portable.

### 7. Exports

Reports can be downloaded as Markdown and PDF from the Streamlit interface.

## Assumptions / mock data

- Public external sources are available during a live run.
- API credentials are supplied through environment variables.
- Test traces are synthetic evaluation tasks created specifically for this assessment.
- No private/company knowledge base is assumed.
- If a provider is unavailable, the agent should expose the limitation rather than pretending it searched that provider.

## Limitations

- Search quality depends on the external provider.
- Lightweight token/Jaccard filtering can miss semantic duplicates.
- Citation verification is based on source IDs supplied to the synthesizer; a production implementation should add claim-level citation validation.
- SQLite is suitable for a single-user assessment/demo, not a distributed multi-user deployment.
- The evaluation traces are small and synthetic.

## Precision / recall approach

The evaluation module supports:
- **Evidence recall:** fraction of expected evidence terms represented in the resulting trace/report.
- **Source precision:** when a trace contains a known expected URL set, fraction of returned URLs matching that set.

Because web results are dynamic, the included trace file uses evidence themes rather than pretending that a fixed URL list is universally correct.

## Production-readiness

The design is suitable as a prototype because components are separated, secrets are environment-based, retrieval is concurrent, outputs are structured, and execution is observable.

For production, I would add:
- stronger semantic reranking
- claim-to-source verification
- source trust policies
- retries/circuit breakers
- rate limits
- authentication
- distributed storage
- background jobs
- comprehensive evaluation benchmarks
- prompt/version tracking
- security/content filtering

## Why this is autonomous

The system does not contain a fixed answer for the research topics. The LLM chooses the research plan, the retrieval layer gathers current external evidence, the filtering stage determines what to retain, and the synthesis stage creates the report from the retrieved evidence.

The deterministic parts provide guardrails and observability; they do not encode a prewritten research answer.
