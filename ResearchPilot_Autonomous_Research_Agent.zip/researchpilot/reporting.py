from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

def markdown_report(report):
    return report["markdown"]

def pdf_report(report, sources):
    r = report["data"]
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    story = [Paragraph(r["title"], styles["Title"]), Spacer(1, 12)]
    story += [Paragraph("Executive Summary", styles["Heading2"]), Paragraph(r["executive_summary"], styles["BodyText"]), Spacer(1, 8)]
    for heading, key in [
        ("Key Points", "key_points"),
        ("Important Findings", "important_findings"),
        ("Actionable Insights", "actionable_insights"),
        ("Limitations", "limitations"),
        ("References", "references"),
    ]:
        story.append(Paragraph(heading, styles["Heading2"]))
        for item in r.get(key, []):
            story.append(Paragraph("• " + item, styles["BodyText"]))
            story.append(Spacer(1, 4))
    story.append(Paragraph("Source Registry", styles["Heading2"]))
    for s in sources:
        story.append(Paragraph(f'[{s["id"]}] {s["title"]} — {s["url"]}', styles["BodyText"]))
    doc.build(story)
    return buf.getvalue()
