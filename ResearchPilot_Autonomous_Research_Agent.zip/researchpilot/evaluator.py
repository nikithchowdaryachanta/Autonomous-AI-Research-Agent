import json
from pathlib import Path

def load_traces(path="sample_data/test_traces.jsonl"):
    return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]

def keyword_recall(expected_terms, observed_text):
    observed = observed_text.lower()
    hits = sum(1 for term in expected_terms if term.lower() in observed)
    return hits / max(1, len(expected_terms))

def evaluate_result(result, trace):
    text = json.dumps(result).lower()
    expected = trace.get("expected_evidence_terms", [])
    recall = keyword_recall(expected, text)
    returned_urls = {s["url"] for s in result.get("sources", [])}
    relevant_urls = set(trace.get("expected_urls", []))
    precision = len(returned_urls & relevant_urls) / max(1, len(returned_urls)) if relevant_urls else None
    return {"trace_id": trace["id"], "evidence_recall": round(recall, 3), "source_precision": precision}
