import concurrent.futures
import hashlib
import re
from typing import List
import requests
from bs4 import BeautifulSoup
from .models import Source

class TavilySource:
    def __init__(self, api_key: str, max_results: int = 6):
        self.api_key = api_key
        self.max_results = max_results

    def search(self, query: str) -> List[Source]:
        if not self.api_key:
            return []
        r = requests.post(
            "https://api.tavily.com/search",
            json={
                "api_key": self.api_key,
                "query": query,
                "search_depth": "advanced",
                "max_results": self.max_results,
                "include_answer": False,
            },
            timeout=30,
        )
        r.raise_for_status()
        out = []
        for item in r.json().get("results", []):
            out.append(Source(
                id="src-" + hashlib.sha1(item["url"].encode()).hexdigest()[:10],
                title=item.get("title", item["url"]),
                url=item["url"],
                snippet=item.get("content", "")[:1800],
                content=item.get("content", ""),
                source_type="web",
                metadata={"provider": "tavily"},
            ))
        return out

class WikipediaSource:
    def search(self, query: str) -> List[Source]:
        r = requests.get(
            "https://en.wikipedia.org/w/api.php",
            params={
                "action": "query", "list": "search", "srsearch": query,
                "format": "json", "srlimit": 5
            },
            timeout=20,
        )
        r.raise_for_status()
        results = r.json().get("query", {}).get("search", [])
        out = []
        for item in results:
            title = item["title"]
            url = "https://en.wikipedia.org/wiki/" + title.replace(" ", "_")
            snippet = BeautifulSoup(item.get("snippet", ""), "html.parser").get_text(" ")
            out.append(Source(
                id="wiki-" + hashlib.sha1(url.encode()).hexdigest()[:10],
                title=title,
                url=url,
                snippet=snippet,
                content=snippet,
                source_type="encyclopedic",
                metadata={"provider": "wikipedia"},
            ))
        return out

def retrieve_parallel(queries, tavily, wikipedia):
    jobs = []
    for q in queries:
        if tavily.api_key:
            jobs.append(("tavily", q, tavily.search))
        jobs.append(("wikipedia", q, wikipedia.search))
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, max(1, len(jobs)))) as pool:
        futures = [pool.submit(fn, q) for _, q, fn in jobs]
        for fut in futures:
            try:
                results.extend(fut.result())
            except Exception:
                continue
    return results

def tokenize(text):
    return set(re.findall(r"[a-zA-Z0-9]{3,}", text.lower()))

def rank_and_deduplicate(sources, query, max_sources):
    q_tokens = tokenize(query)
    scored = []
    for s in sources:
        t = tokenize((s.title + " " + s.snippet + " " + s.content)[:8000])
        overlap = len(q_tokens & t) / max(1, len(q_tokens))
        s.relevance_score = round(min(1.0, overlap), 3)
        scored.append(s)

    scored.sort(key=lambda x: x.relevance_score, reverse=True)

    kept, duplicate_count = [], 0
    seen_urls, seen_signatures = set(), []
    for s in scored:
        canonical = s.url.lower().rstrip("/")
        if canonical in seen_urls:
            duplicate_count += 1
            continue
        sig = tokenize(s.title + " " + s.snippet)
        is_dup = any(len(sig & old) / max(1, len(sig | old)) >= 0.78 for old in seen_signatures)
        if is_dup:
            duplicate_count += 1
            continue
        seen_urls.add(canonical)
        seen_signatures.append(sig)
        kept.append(s)
        if len(kept) >= max_sources:
            break
    return kept, duplicate_count
