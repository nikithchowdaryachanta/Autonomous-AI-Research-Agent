import json
import time
from .config import Settings
from .llm import LLMClient
from .models import ResearchPlan, ResearchReport
from .sources import TavilySource, WikipediaSource, retrieve_parallel, rank_and_deduplicate
from .memory import MemoryStore

PLANNER_SYSTEM = """You are the planning component of an autonomous research agent.
Given a user research question, decide what information is needed, which external source
types are appropriate, and generate several focused search queries. Do not answer the
research question. Return only the requested structured plan."""

SYNTHESIS_SYSTEM = """You are the synthesis component of an autonomous research agent.
Use ONLY the supplied evidence pack. Produce a useful research report. Every material
finding must cite one or more source IDs like [src-abc123]. If evidence is insufficient,
say so. Never invent a URL, statistic, study, quote, or reference. Distinguish evidence
from interpretation and include actionable insights only when supported."""

class ResearchAgent:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.llm = LLMClient(settings.openai_api_key, settings.openai_model)
        self.tavily = TavilySource(settings.tavily_api_key, settings.tavily_max_results)
        self.wikipedia = WikipediaSource()
        self.memory = MemoryStore(settings.app_db_path)

    def run(self, query, max_sources=6, use_memory=True):
        started = time.perf_counter()
        trace = []

        trace.append({"step": "received_query", "query": query})

        plan = self.llm.structured(
            PLANNER_SYSTEM,
            f"Research question: {query}",
            ResearchPlan,
        )
        trace.append({
            "step": "planned_research",
            "intent": plan.intent,
            "queries": plan.search_queries,
            "source_types": plan.preferred_source_types,
            "reasoning": plan.reasoning,
        })

        if use_memory:
            previous = self.memory.recent(3)
            if previous:
                trace.append({"step": "memory_retrieved", "count": len(previous)})

        raw = retrieve_parallel(plan.search_queries, self.tavily, self.wikipedia)
        trace.append({"step": "parallel_retrieval", "raw_sources": len(raw)})

        sources, duplicates = rank_and_deduplicate(raw, query, max_sources)
        trace.append({
            "step": "filtering",
            "retained": len(sources),
            "duplicates_removed": duplicates,
        })

        evidence = []
        for s in sources:
            evidence.append({
                "id": s.id, "title": s.title, "url": s.url,
                "source_type": s.source_type,
                "relevance_score": s.relevance_score,
                "content": (s.content or s.snippet)[:5000],
            })

        report = self.llm.structured(
            SYNTHESIS_SYSTEM,
            json.dumps({
                "question": query,
                "research_plan": plan.model_dump(),
                "evidence": evidence,
            }, ensure_ascii=False),
            ResearchReport,
        )

        report_dict = report.model_dump()
        trace.append({"step": "synthesis_complete", "references": len(report.references)})

        latency = time.perf_counter() - started
        metrics = {
            "sources_gathered": len(raw),
            "sources_retained": len(sources),
            "duplicates_removed": duplicates,
            "latency_seconds": round(latency, 3),
            "queries_planned": len(plan.search_queries),
            "references_generated": len(report.references),
        }

        result = {
            "query": query,
            "plan": plan.model_dump(),
            "sources": [s.model_dump() for s in sources],
            "report": {
                "data": report_dict,
                "markdown": markdown_from_report(report_dict),
            },
            "trace": trace,
            "metrics": metrics,
        }

        if use_memory:
            self.memory.save(query, result)
        return result

def markdown_from_report(r):
    lines = [f"# {r['title']}", "", "## Executive Summary", r["executive_summary"], ""]
    for heading, key in [
        ("Key Points", "key_points"),
        ("Important Findings", "important_findings"),
        ("Actionable Insights", "actionable_insights"),
        ("Limitations", "limitations"),
        ("References", "references"),
    ]:
        lines += [f"## {heading}"]
        for item in r.get(key, []):
            lines.append(f"- {item}")
        lines.append("")
    return "\n".join(lines)
