import argparse
from .agent import ResearchAgent
from .config import Settings

def main():
    p = argparse.ArgumentParser()
    p.add_argument("query")
    p.add_argument("--max-sources", type=int, default=6)
    args = p.parse_args()
    result = ResearchAgent(Settings()).run(args.query, args.max_sources)
    print(result["report"]["markdown"])

if __name__ == "__main__":
    main()
